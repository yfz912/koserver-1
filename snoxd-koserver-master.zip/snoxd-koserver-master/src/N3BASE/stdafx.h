#pragma once

#include "../shared/stdafx.h"

#include <limits>
#include "N3ShapeMgr.h"