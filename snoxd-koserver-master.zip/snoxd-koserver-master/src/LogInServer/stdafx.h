#pragma once

#include "../shared/stdafx.h"

#include "Define.h"
#include "DBProcess.h"
#include "LoginServer.h"
#include "LoginSession.h"

using namespace std;
