#pragma once

LUA_FUNCTION(CheckPercent);
LUA_FUNCTION(HowmuchItem);
LUA_FUNCTION(ShowMap);
LUA_FUNCTION(CheckNation);
LUA_FUNCTION(CheckClass);
LUA_FUNCTION(CheckLevel);
LUA_FUNCTION(CheckSkillPoint);
LUA_FUNCTION(SaveEvent);
LUA_FUNCTION(CheckExchange);
LUA_FUNCTION(RunExchange);
LUA_FUNCTION(SearchQuest);
LUA_FUNCTION(NpcMsg);
LUA_FUNCTION(RobItem);
LUA_FUNCTION(GiveItem);
LUA_FUNCTION(ShowEffect);
LUA_FUNCTION(ShowNpcEffect);
LUA_FUNCTION(PromoteUserNovice);
LUA_FUNCTION(PromoteUser);
LUA_FUNCTION(ExistMonsterQuestSub);
LUA_FUNCTION(PromoteKnight);
LUA_FUNCTION(CheckClanGrade);
LUA_FUNCTION(CheckKnight);
LUA_FUNCTION(CheckLoyalty);
LUA_FUNCTION(CheckStatPoint);
LUA_FUNCTION(SelectMsg);
LUA_FUNCTION(CastSkill);
