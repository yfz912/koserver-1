#pragma once

#include "../shared/stdafx.h"

#include <math.h>
#include "Define.h"			// define
#include "ServerDlg.h"

extern bool g_bRunning;