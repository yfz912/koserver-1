#pragma once

void FormattedDebugString(const char * fmt, ...);