#pragma once

#define __VERSION 1886