#pragma once

void OnSignal(int s);
void HookSignals(Condition * notifier);
void UnhookSignals();