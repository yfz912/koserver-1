EXEC sp_rename 'SET_ITEM.Unk3' , 'APBonusPercent', 'COLUMN'
GO
EXEC sp_rename 'SET_ITEM.Unk4' , 'APBonusClassType', 'COLUMN'
GO
EXEC sp_rename 'SET_ITEM.Unk5' , 'APBonusClassPercent', 'COLUMN'
GO
EXEC sp_rename 'SET_ITEM.Unk6' , 'ACBonusClassType', 'COLUMN'
GO
EXEC sp_rename 'SET_ITEM.Unk7' , 'ACBonusClassPercent', 'COLUMN'
GO
