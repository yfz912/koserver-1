EXEC sp_rename 'SET_ITEM.Unk8' , 'MaxWeightBonus', 'COLUMN'
GO
EXEC sp_rename 'SET_ITEM.Unk9' , 'NPBonus', 'COLUMN'
GO
EXEC sp_rename 'SET_ITEM.Unk1' , 'XPBonusPercent', 'COLUMN'
GO
EXEC sp_rename 'SET_ITEM.Unk2' , 'CoinBonusPercent', 'COLUMN'
GO
