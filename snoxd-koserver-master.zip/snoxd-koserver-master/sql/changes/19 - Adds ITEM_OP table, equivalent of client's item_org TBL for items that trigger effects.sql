CREATE TABLE [ITEM_OP](
	[nItemID] [int] NOT NULL,
	[bTriggerType] [tinyint] NOT NULL,
	[nSkillID] [int] NOT NULL,
	[bTriggerRate] [tinyint] NOT NULL
)
